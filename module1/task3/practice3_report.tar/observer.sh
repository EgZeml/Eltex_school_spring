#!/bin/bash

CONFIG_FILE="scripts.conf"
LOG_FILE="observer.log"

# Проверка, существует ли конфиг
if [ ! -f "$CONFIG_FILE" ]; then
  echo "[$(date '+%Y-%m-%d %H:%M:%S')] Конфигурационный файл $CONFIG_FILE не найден!" >> "$LOG_FILE"
  exit 1
fi

# Читаем скрипты из конфига
while read -r SCRIPT_PATH; do
  # Пропускаем пустые строки и комментарии
  [[ -z "$SCRIPT_PATH" || "$SCRIPT_PATH" == \#* ]] && continue

  # Проверяем, существует ли файл скрипта
  if [ ! -f "$SCRIPT_PATH" ]; then
    echo "[$(date '+%Y-%m-%d %H:%M:%S')] Скрипт $SCRIPT_PATH не найден" >> "$LOG_FILE"
    continue
  fi

  # Проверка: есть ли уже запущенный процесс этого скрипта
  if ! pgrep -f "$SCRIPT_PATH" > /dev/null; then
    nohup bash "$SCRIPT_PATH" > /dev/null 2>&1 &
    echo "[$(date '+%Y-%m-%d %H:%M:%S')] Перезапущен скрипт: $SCRIPT_PATH" >> "$LOG_FILE"
  fi

done < "$CONFIG_FILE"
