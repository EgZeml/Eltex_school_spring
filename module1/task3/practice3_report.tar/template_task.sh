#!/bin/bash

# Получаем имя скрипта без пути и расширения
SCRIPT_NAME=$(basename "$0")
LOG_FILE="report_${SCRIPT_NAME}.log"

# Получаем PID и текущую дату/время
PID=$$
START_TIME=$(date '+%Y-%m-%d %H:%M:%S')

# Логируем запуск
echo "[$PID] $START_TIME Скрипт запущен" >> "$LOG_FILE"

# Генерируем случайное число от 30 до 1800
SLEEP_TIME=$(( RANDOM % 1771 + 30 ))

# Ждём это время
sleep "$SLEEP_TIME"

# Рассчитываем, сколько минут прошло
MINUTES=$(( SLEEP_TIME / 60 ))

# Логируем завершение
END_TIME=$(date '+%Y-%m-%d %H:%M:%S')
echo "[$PID] $END_TIME Скрипт завершился, работал $MINUTES минут" >> "$LOG_FILE"

